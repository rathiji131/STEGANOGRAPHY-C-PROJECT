#include <stdio.h>
#include "decode.h"
#include "types.h"
#include <string.h>
#include "common.h"
#include <math.h>
/* Function Definitions */

//checking input operation type i.e -e or -d
OperationType check_decode_operation_type (char *argv[])
{
    if(strcmp(argv[1],"-d") == 0)
        return e_decode;
    else
        return e_unsupported;
}

//validating the input areguments 
Status read_and_validate_decode_args(char **argv ,DecodeInfo *decInfo)
{
    if(strcmp((strstr(argv[2],".")),".bmp") == 0)
    {
        decInfo->stego_image_fname = argv[2];
    }
    else
    {
        return e_failure;
    }
    if(argv[3] != NULL)
    {
        decInfo->decode_secret_fname = argv[3];
        return e_success;
    }
    else
    {
        decInfo->decode_secret_fname = "secret_decode.txt";
        return e_success;
    }
}

//Opening the files in read and write mode
Status open_decode_files(DecodeInfo *decInfo)
{
    // Secret file
    decInfo->fptr_decode_secret = fopen(decInfo->decode_secret_fname, "w");
    // Do Error handling
    if (decInfo->fptr_decode_secret == NULL)
    {
        perror("fopen");
        fprintf(stderr, "ERROR: Unable to open file %s\n", decInfo->decode_secret_fname);
        return e_failure;
    }

    // Stego Image file
    decInfo->fptr_stego_image = fopen(decInfo->stego_image_fname, "r");
    // Do Error handling
    if (decInfo->fptr_stego_image == NULL)
    {
        perror("fopen");
        fprintf(stderr, "ERROR: Unable to open file %s\n", decInfo->stego_image_fname);
        return e_failure;
    }
    return e_success;
}

//decoding magic string using decode_data_from_image
Status decode_magic_string(DecodeInfo *decInfo)
{
    fseek(decInfo->fptr_stego_image,54,SEEK_SET);
    printf("Magic string is : ");
    decode_data_from_image(2,decInfo->fptr_stego_image, decInfo->fptr_decode_secret,decInfo);
    printf("\n");
    return e_success;
}

//decoding secret file extension size using decode size from lsb functin
Status decode_secret_file_ext_size(FILE *fptr_stego_image,DecodeInfo *decInfo)
{
    char str[32];
    fread(str, 32, 1, fptr_stego_image);
    decInfo->extn_size= decode_size_from_lsb(str);
    printf("secret file extension size : %d\n",decInfo->extn_size);
    return e_success;
}

//decoding secet file extension using decode_data_from_image function
Status decode_secret_file_extn(DecodeInfo *decInfo)
{
    printf("secret file extension is : ");
    decode_data_from_image(decInfo->extn_size, decInfo->fptr_stego_image, decInfo->fptr_decode_secret, decInfo);
    printf("\n");
    return e_success;
}

//decoding data from stego image
Status decode_data_from_image(int size , FILE *fptr_stego_image , FILE *fptr_decode_secret, DecodeInfo *decInfo)
{
    for(int i = 0 ; i < size ; i++)
    {
        fread(decInfo->image_data,8,1,decInfo->fptr_stego_image);
        decode_byte_from_lsb(1,decInfo->image_data,fptr_decode_secret,decInfo);
    }
    return e_success;
}

//decoding lsb of data to form a single charecter
Status decode_byte_from_lsb(int flag ,const char data[8] , FILE *fptr_decode_secret,DecodeInfo *decInfo)
{
    int i = 0 ;
    unsigned int mask = 0x01;
    char ch=0;
    for( i = 0; i < 8; i++)
    {
        ch  =  ch | ((data[i] & mask ) << (7-i));
    }
    printf("%c",ch);
    if(flag == 1)
    {       
        fwrite(&ch,1,1,fptr_decode_secret);
    }
    return e_success;
}

//decoding secret file size from lsb function
unsigned int decode_size_from_lsb(char *buffer)
{
    int i;
    unsigned int mask = 0x01,size=0;
    for(i = 0; i < 32; i++)
    {
        size = size | ((buffer[i] & mask ) << (31-i));
    }
    return size;
}

//decoding secret file size which interns call secet file size from lsb
uint decode_secret_file_size(DecodeInfo *decInfo)
{
    char str[32];
    fread(str,32,1,decInfo->fptr_stego_image);
    decInfo->size_secret_file = decode_size_from_lsb(str);
    printf("secret file size : %d\n",decInfo->size_secret_file);
    return decInfo->size_secret_file;
}

//decoding secret filr data from stego image
Status decode_secret_file_data(DecodeInfo *decInfo)
{
    fseek(decInfo->fptr_decode_secret,0,SEEK_SET);
    uint size = decode_secret_file_size(decInfo);
    char str[decInfo->size_secret_file];
    printf("Secret file data is : ");
    decode_data_from_image(decInfo->size_secret_file,decInfo->fptr_stego_image,decInfo->fptr_decode_secret,decInfo);
    return e_success;
}

//every above functions are called in this function
Status do_decoding (DecodeInfo *decInfo)
{
    if(open_decode_files(decInfo) == e_success)
    {
        printf("Open files is successful\n");
        if(decode_magic_string(decInfo) == e_success)
        {
            printf("Decoding magic string is success\n");
            if(decode_secret_file_ext_size(decInfo->fptr_stego_image,decInfo) == e_success)
            {   
                printf("Decoding secret file extension size is successful\n");
                if (decode_secret_file_extn(decInfo) == e_success)
                {
                    printf("Decoding secret file extension is successful\n");
                    if(decode_secret_file_data(decInfo) == e_success)
                    {
                        printf("Decoding secret file data is successful\n");
                        e_success;
                    }
                    else
                    {
                        printf("Decoding secret file data was not successful\n");
                    }
                }
                else
                {
                    printf("Decoding seret file extension is not successful\n");
                }
            }
            else
            {
                printf("Decoding secret file extension is not successful\n");
            }
        }
        else
        {
            printf("Decoding magic string is not successful\n");
        }
    }
    else
    {
        printf("Open files is not successful\n");
    }
    return e_success;
}

